const swiperBuilding = new Swiper('.swiper-building', {
 
    spaceBetween: 22,
    slidesPerView: 1.05,
  
  });

  const swiperFeatures = new Swiper('.swiper-features', {
 
    spaceBetween: 22,
    slidesPerView: 1.05,
  
  });